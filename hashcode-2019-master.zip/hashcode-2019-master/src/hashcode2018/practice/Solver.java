package hashcode2018.practice;

import java.util.List;

abstract public class Solver {

	protected abstract List<Slice> solve(PizzaProblem pizzaProblem);

}
