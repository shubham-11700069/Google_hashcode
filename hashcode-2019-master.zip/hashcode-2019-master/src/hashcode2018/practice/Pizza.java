package hashcode2018.practice;

public class Pizza {

	public Pizza() {
		// TODO Auto-generated constructor stub
	}

}
