package hashcode2018.practice;
public class Shape extends Pair {

	public Shape(int w, int h) {
		super(w, h);
	}

}
