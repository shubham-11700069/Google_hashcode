
# A Solution to Google Hash Code Practice Problem 2019 

It is Java implementation from [http://flothesof.github.io/preparing-hashcode-2018.html](http://flothesof.github.io/preparing-hashcode-2018.html) with tiny changes
